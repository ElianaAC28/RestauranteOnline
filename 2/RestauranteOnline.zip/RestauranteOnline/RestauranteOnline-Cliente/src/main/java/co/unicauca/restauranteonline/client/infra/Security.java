
package co.unicauca.restauranteonline.client.infra;

import co.unicauca.resturanteonline.client.domain.User;

/**
 * Esta pendiente implementar esta clase. Tendra la responsabilidad de cosas
 * de seguridad, por ejemplo, almacenar el usuario autenticado
 * @author Libardo, Julio
 */
public class Security {
    public static User usuario;    
}
